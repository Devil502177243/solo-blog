title: SpringCloud 基础配置
date: '2019-11-12 17:31:49'
updated: '2019-11-12 17:35:33'
tags: [cloud学习]
permalink: /articles/2019/11/12/1573551109000.html
---
## 一、配置文件

1. ## YAM 与 properties

   ```
   YAM 和 properties 文件是一样的原理，且一个项目上要么 YAM 或者 properties，二选一的存在
   ```
2. ## YAM 语法

* ### **大小写敏感**

  ```
  json 里也是大小写敏感的，这点二者一样。
  ```
* ### **使用缩进表示层级关系**

  ```
  json 中使用 `{}` 的嵌套表示层级，而 yaml 使用缩进，后者更方便一些。
  ```
* ### **`#` 表示注释**

  ```
  json 文件中不允许写注释，对于很长配置文件全靠字面意思猜挺痛快的，yaml 可以写注释
  ```

3. ## 数据结构

   配置文件理应十分简洁，与 JSON 相比，不用频繁的写 `{}` 和 `[]`，毕竟换行和 `-` 符号更加简洁，字符 串也不需要频繁的加引号（无论是单引号还是双引号）。

* ### 对象

  ```css
  # conf.yml
  animal: pets
  hash: { name: Steve, foo: bar }
  ```
* ### 转换为 JSON 为：

  ```
  {
    { "animal": "pets" },
    { "hash": { "name": "Steve", "foo": "bar" } }
  }
  ```
* ### 数组

  ```bash
  # conf.yml
  Animal:
  - Cat
  - Dog
  - Goldfish
  ```
* ### 转换为 JSON 为：

  ```json
  { "Animal": [ "Cat", "Dog", "Goldfish" ] }
  ```
* ### 字符串

  ```
  # conf.yml
  # 正常情况下字符串不用写引号
  str: 这是一行字符串
  # 字符串内有空格或者特殊字符时需要加引号
  str: '内容： 字符串'
  ```
* ### null

  ```php
  # conf.yml
  parent: ~
  ```
* ### .yml 中 ~ 表示 null，转换为 JSON 为：

  ```json
  { "parent": null }
  ```
## 二、Application相关注解

